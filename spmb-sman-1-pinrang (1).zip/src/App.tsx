import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Award, 
  BookOpen, 
  Heart, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Calendar, 
  ChevronRight, 
  GraduationCap, 
  School, 
  User, 
  Hash, 
  ArrowLeft, 
  Copy, 
  Check,
  ShieldCheck,
  HelpCircle,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { STUDENTS_DATA } from './data/students';
import { Student } from './types';
import OfficialLetter from './components/OfficialLetter';

export default function App() {
  const [nisnInput, setNisnInput] = useState('');
  const [typedNisnCount, setTypedNisnCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedStudent, setSearchedStudent] = useState<Student | null | undefined>(undefined);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [showOfficialCertificate, setShowOfficialCertificate] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Auto-set typed counter
  useEffect(() => {
    setTypedNisnCount(nisnInput.length);
    if (validationError && nisnInput.length === 10) {
      setValidationError(null);
    }
  }, [nisnInput, validationError]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNisn = nisnInput.trim();
    
    // Validation
    if (cleanNisn.length !== 10 || !/^\d+$/.test(cleanNisn)) {
      setValidationError('NISN harus berupa 10 digit angka.');
      return;
    }

    setValidationError(null);
    setSearchQuery(cleanNisn);

    // Look up in database (supporting both exact and leading zero variations)
    const normalizedNisn = cleanNisn.startsWith('0') ? cleanNisn : '0' + cleanNisn;
    const student = STUDENTS_DATA.find(s => s.nisn === cleanNisn || s.nisn === normalizedNisn);
    
    if (student) {
      setSearchedStudent(student);
      setShowOfficialCertificate(false);
      // Trigger confetti if passed
      if (student.isPassed) {
        triggerConfettiCascade();
      }
    } else {
      // According to request, any NISN not found in the database file is declared NOT PASSED
      setSearchedStudent({
        nisn: cleanNisn,
        name: 'Calon Peserta Didik Baru',
        gender: '-',
        schoolOrigin: '-',
        jalur: 'Jalur Mutasi',
        score: 0.00,
        isPassed: false
      });
      setShowOfficialCertificate(false);
    }
  };

  const triggerConfettiCascade = () => {
    const duration = 3 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 100 };

    const randomInRange = (min: number, max: number) => {
      return Math.random() * (max - min) + min;
    };

    const intervalId = window.setInterval(() => {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(intervalId);
      }

      const particleCount = 50 * (timeLeft / duration);
      // since particles fall down, animate a bit higher than random
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  const handleResetSearch = () => {
    setNisnInput('');
    setSearchQuery('');
    setSearchedStudent(undefined);
    setShowOfficialCertificate(false);
  };

  const handleCopyNisn = (nisn: string) => {
    navigator.clipboard.writeText(nisn);
    setCopiedText(nisn);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleQuickCheck = (nisn: string) => {
    setNisnInput(nisn);
    setValidationError(null);
    const normalizedNisn = nisn.startsWith('0') ? nisn : '0' + nisn;
    const student = STUDENTS_DATA.find(s => s.nisn === nisn || s.nisn === normalizedNisn);
    setSearchQuery(nisn);
    if (student) {
      setSearchedStudent(student);
      setShowOfficialCertificate(false);
      if (student.isPassed) {
        triggerConfettiCascade();
      }
    } else {
      setSearchedStudent({
        nisn: nisn,
        name: 'Calon Peserta Didik Baru',
        gender: '-',
        schoolOrigin: '-',
        jalur: 'Mutasi',
        score: 0.00,
        isPassed: false
      });
      setShowOfficialCertificate(false);
    }
  };

  // If viewing the printable Certificate/Letter view
  if (showOfficialCertificate && searchedStudent && searchedStudent.isPassed) {
    return (
      <div className="min-h-screen bg-slate-50 py-6 sm:py-10">
        <OfficialLetter 
          student={searchedStudent} 
          onBack={() => setShowOfficialCertificate(false)} 
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col justify-between selection:bg-blue-100 selection:text-blue-900 bg-slate-50 font-sans text-slate-900">
      
      {/* HEADER / LOGO BAR */}
      <header className="no-print w-full py-5 px-6 bg-white border-b border-slate-200">
        <div className="max-w-xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 flex items-center justify-center shrink-0">
              <img 
                src="/SMA Negeri 1 Pinrang.png" 
                alt="Logo SMAN 1 Pinrang" 
                className="w-12 h-12 object-contain" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="text-sm font-extrabold uppercase tracking-widest text-slate-900 leading-tight">SPMB PORTAL</h1>
              <p className="text-[11px] text-slate-500 font-medium">UPT SMAN 1 Pinrang</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100 font-bold text-[10px] tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
            <span>TA 2026/2027</span>
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 w-full max-w-xl mx-auto px-4 py-8 sm:py-12 flex flex-col justify-start">
        <AnimatePresence mode="wait">
          
          {/* STATE: HOME/SEARCH FORM */}
          {searchedStudent === undefined && (
            <motion.div
              key="search-section"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col gap-6"
            >
              {/* HERO DESCRIPTIONS */}
              <div className="text-center py-2 space-y-3">
                <span className="inline-flex rounded-full bg-blue-50 px-3.5 py-1 text-xs font-bold text-blue-600 border border-blue-100 shadow-2xs">
                  Sistem Penerimaan Murid Baru
                </span>
                <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight leading-tight">
                  Pengumuman Resmi <br className="hidden sm:inline" />
                  <span className="text-blue-600">SPMB SMAN 1 Pinrang</span>
                </h2>
                <div className="space-y-1">
                  <p className="text-indigo-650 font-bold uppercase tracking-widest text-xs text-blue-600">
                    Tahun Ajaran 2026/2027
                  </p>
                  <p className="text-xs sm:text-sm text-slate-500 font-medium max-w-sm mx-auto pt-1 leading-relaxed">
                    Jalur Zona 1, Afirmasi, &amp; Perpindahan Tugas Orang Tua (Mutasi).
                  </p>
                </div>
              </div>

              {/* Minimal Clean Search Card */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-blue-600"></div>
                
                <form onSubmit={handleSearch} className="space-y-5">
                  <div>
                    <label 
                      htmlFor="nisn" 
                      className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center justify-between"
                    >
                      <span>Masukkan 10 Digit NISN Kamu:</span>
                      <span className={`font-mono text-[11px] ${typedNisnCount === 10 ? 'text-emerald-600 font-bold' : typedNisnCount > 10 ? 'text-red-500 font-bold' : 'text-slate-400'}`}>
                        {typedNisnCount} / 10
                      </span>
                    </label>
                    <div className="relative rounded-xl shadow-2xs">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                        <Hash className="w-5 h-5 text-slate-400 shrink-0" />
                      </div>
                      <input
                        id="nisn"
                        type="text"
                        name="nisn"
                        pattern="\d*"
                        maxLength={10}
                        value={nisnInput}
                        onChange={(e) => setNisnInput(e.target.value.replace(/\D/g, ''))}
                        placeholder="Contoh: 0081234567"
                        className={`block w-full pl-12 pr-4 py-4 text-base sm:text-lg text-slate-900 bg-slate-50 border rounded-xl placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500/15 focus:bg-white transition-all duration-200 ${
                          validationError 
                            ? 'border-red-300' 
                            : 'border-slate-200'
                        }`}
                        aria-describedby="nisn-error"
                      />
                    </div>
                    {validationError && (
                      <p className="mt-2 text-xs font-bold text-red-600 flex items-center gap-1.5" id="nisn-error">
                        <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                        {validationError}
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full h-14 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-100 flex items-center justify-center gap-2 text-base cursor-pointer active:scale-[0.99] select-none"
                  >
                    <Search className="w-5 h-5" />
                    Cek Status Kelulusan
                  </button>
                </form>

                {/* Footnote */}
                <p className="mt-5 text-[11px] leading-relaxed text-slate-400 border-t border-slate-100 pt-4 text-center italic">
                  Pastikan nomor NISN yang Anda masukkan sudah benar. Jika mengalami kendala, hubungi Panitia PPDB SMAN 1 Pinrang.
                </p>
              </div>
            </motion.div>
          )}

          {/* STATE: DISPLAY SEARCH RESULTS */}
          {searchedStudent !== undefined && (
            <motion.div
              key="result-section"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            >
              
              {/* CASE A: LULUS */}
              {searchedStudent && searchedStudent.isPassed && (
                <div className="flex flex-col gap-6">
                  {/* Clean Minimalist Success Banner Card */}
                  <div className="bg-emerald-50 border border-emerald-100 rounded-3xl p-8 sm:p-10 shadow-sm relative overflow-hidden flex flex-col items-center text-center">
                    <div className="absolute top-0 right-0 p-8 opacity-5">
                      <svg className="w-36 h-36 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                      </svg>
                    </div>

                    <div className="inline-block px-4 py-1.5 bg-emerald-500 text-white text-[10px] font-black uppercase rounded-full mb-6 tracking-widest leading-none animate-pulse">
                      Dinyatakan LULUS
                    </div>
                    
                    <h2 className="text-3xl font-extrabold text-emerald-950 tracking-tight mb-2">
                      🎉 SELAMAT!
                    </h2>
                    <p className="text-emerald-700 font-medium text-sm sm:text-base max-w-xs sm:max-w-md">
                      Anda Dinyatakan LULUS Calon Peserta Didik Baru SMAN 1 Pinrang
                    </p>
                  </div>

                  {/* Clean Minimalist Bordered Grid Biodata */}
                  <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-2xs">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                      <User className="w-4 h-4 text-emerald-600" />
                      Biodata Kelulusan
                    </h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-5 gap-x-10 text-sm">
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Nama Lengkap</span>
                        <span className="font-extrabold text-slate-900">{searchedStudent.name}</span>
                      </div>
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Nomor NISN</span>
                        <span className="font-bold text-slate-900 tracking-wider font-mono">{searchedStudent.nisn}</span>
                      </div>
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Jenis Kelamin</span>
                        <span className="font-semibold text-slate-800">{searchedStudent.gender}</span>
                      </div>
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Asal Sekolah</span>
                        <span className="font-semibold text-slate-800">{searchedStudent.schoolOrigin}</span>
                      </div>
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Jalur Pendaftaran</span>
                        <span className="font-bold text-blue-600">{searchedStudent.jalur}</span>
                      </div>
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Skor Akhir</span>
                        <span className="font-extrabold text-emerald-600 text-base">{searchedStudent.score.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Next Step Box */}
                  <div className="bg-emerald-50 bg-opacity-40 border border-emerald-100 rounded-2xl p-5 sm:p-6 flex flex-col gap-4 text-xs sm:text-sm text-emerald-950 max-w-2xl">
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 shrink-0 mt-0.5">
                        <Calendar className="w-5 h-5 shrink-0" />
                      </div>
                      <div>
                        <p className="font-extrabold text-emerald-950">Jadwal Daftar Ulang:</p>
                        <p className="mt-1 leading-relaxed text-slate-705 font-bold text-sm bg-white/80 px-3 py-1.5 rounded-lg border border-emerald-100 inline-block">
                          12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA
                        </p>
                        <p className="mt-1 text-xs text-slate-600 font-medium leading-relaxed">
                          Silakan melakukan pendaftaran ulang pada tanggal dan waktu tersebut secara langsung ke sekretariat PPDB SMAN 1 Pinrang. Jangan sampai terlambat!
                        </p>
                      </div>
                    </div>

                    <div className="border-t border-emerald-200/50 pt-4">
                      <div className="flex gap-4">
                        <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-700 shrink-0 mt-0.5">
                          <FileText className="w-5 h-5 shrink-0" />
                        </div>
                        <div className="flex-1">
                          <p className="font-extrabold text-slate-900">Berkas Pendaftaran Ulang yang Harus Disiapkan:</p>
                          <p className="text-[11px] text-slate-500 mb-2.5 font-medium">Harap mempersiapkan berkas-berkas berikut ini di dalam map:</p>
                          
                          <ul className="space-y-1.5 text-xs text-slate-700 font-semibold">
                            {[
                              "Bukti Pendaftaran dan Verifikasi",
                              "Fotocopy Rapor 1 Rangkap",
                              "Surat Keterangan Lulus Asli",
                              "Fotocopy Ijazah SD (2 Lembar)",
                              "Fotocopy Akta Kelahiran & KK (2 Lembar)",
                              "Pas Foto 3 x 4 (3 Lembar)",
                              "Pakta Integritas"
                            ].map((doc, idx) => (
                              <li key={idx} className="flex items-start gap-2 bg-white/60 p-2 rounded-lg border border-slate-100 shadow-2xs">
                                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-slate-100 text-[10px] font-black text-slate-750 shrink-0">
                                  {idx + 1}
                                </span>
                                <span className="text-slate-800 self-center leading-tight">{doc}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* CTAs */}
                  <div className="flex flex-col gap-3">
                    <button
                      onClick={handleResetSearch}
                      className="w-full py-4 bg-slate-100 hover:bg-slate-200/80 text-slate-700 font-bold rounded-xl transition-all flex items-center justify-center gap-2 text-sm cursor-pointer"
                    >
                      <ArrowLeft className="w-4 h-4 text-slate-500" />
                      Kembali ke Pencarian
                    </button>
                  </div>
                </div>
              )}

              {/* CASE B: BELUM LULUS */}
              {searchedStudent && !searchedStudent.isPassed && (
                <div className="flex flex-col gap-6">
                  {/* Calming Slate Minimalist Banner Card */}
                  <div className="bg-slate-100 border border-slate-200 rounded-3xl p-8 sm:p-10 text-center flex flex-col items-center">
                    <div className="w-14 h-14 bg-slate-200/60 rounded-full flex items-center justify-center mb-4 text-slate-500">
                      <Heart className="w-7 h-7 fill-slate-400 text-slate-500 animate-pulse" />
                    </div>
                    
                    <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-850 tracking-tight leading-none mb-2">
                      ❤️ TETAP SEMANGAT & PANTANG MENYERAH!
                    </h2>
                    <p className="text-sm font-semibold text-slate-500 mt-1 max-w-xs sm:max-w-md">
                      Terima kasih yang sebesar-besarnya atas segala perjuangan dan antusiasme Anda dalam SPMB SMAN 1 Pinrang.
                    </p>
                    <p className="text-base sm:text-lg font-extrabold text-rose-700 mt-5 px-6 py-3.5 rounded-2xl bg-rose-50 border border-rose-100 shadow-3xs max-w-xs sm:max-w-md">
                      Maaf, Anda dinyatakan belum lulus seleksi pada jalur ini
                    </p>
                  </div>

                  {/* Clean Minimalist Bordered Grid Biodata */}
                  <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-2xs">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-500" />
                      Data Pendaftaran
                    </h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-5 gap-x-10 text-sm">
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Nama Lengkap</span>
                        <span className="font-extrabold text-slate-900">{searchedStudent.name}</span>
                      </div>
                      <div className="border-b border-slate-100 pb-3">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">Nomor NISN</span>
                        <span className="font-bold text-slate-900 tracking-wider font-mono">{searchedStudent.nisn}</span>
                      </div>
                    </div>
                  </div>

                  {/* Comforting Message */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-2">
                    <h4 className="font-bold text-slate-800 text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 border-b border-slate-200/60 pb-2">
                      <BookOpen className="w-4 h-4 text-blue-600" />
                      Pesan Hangat Untukmu:
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-bold">
                      Tetap semangat! Kegagalan hari ini bukanlah akhir dari segalanya.
                    </p>
                    <p className="text-xs sm:text-sm text-slate-650 leading-relaxed font-medium">
                      Jangan berkecil hati, perjuanganmu masih panjang. Silakan persiapkan diri untuk mencoba jalur pendaftaran lain yang masih terbuka atau tahap seleksi berikutnya di SMAN 1 Pinrang. Kamu pasti bisa!
                    </p>
                  </div>

                  {/* Retake/Back Navigation */}
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={handleResetSearch}
                      className="w-full h-14 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-2 text-base cursor-pointer"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      Kembali ke Pencarian
                    </button>
                    <p className="text-center text-[10px] text-slate-400 font-medium">
                      Hubungi Sekretariat Panitia PPDB SMAN 1 Pinrang jika memerlukan bantunan informasi lebih lanjut.
                    </p>
                  </div>
                </div>
              )}

              {/* CASE C: NOT FOUND */}
              {searchedStudent === null && (
                <div className="flex flex-col gap-6">
                  <div className="bg-amber-50 border border-amber-200 rounded-3xl p-6 sm:p-8 text-center flex flex-col items-center">
                    <div className="w-12 h-12 bg-amber-550 border border-amber-300 text-amber-700 rounded-xl flex items-center justify-center mb-3">
                      <AlertCircle className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-extrabold text-amber-900 tracking-tight uppercase">DATA TIDAK DITEMUKAN</h3>
                    <p className="text-xs text-amber-700 mt-2 max-w-sm font-medium">
                      NISN <strong className="font-mono text-amber-950 font-black">{searchQuery}</strong> belum terdaftar dalam database SPMB SMAN 1 Pinrang Tahun Pelajaran 2026/2027.
                    </p>
                  </div>

                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs text-xs sm:text-sm text-slate-800">
                    <p className="font-bold mb-2 text-slate-900">Periksa Kembali:</p>
                    <ul className="list-disc pl-5 space-y-1.5 text-slate-500 font-medium">
                      <li>Pastikan NISN yang dimasukkan adalah <strong>10 digit angka</strong> utuh.</li>
                      <li>Periksa kembali angka satu per satu dari kartu ujian PPDB Anda.</li>
                      <li>Atau gunakan salah satu <strong>Nomor Uji Coba</strong> di halaman sebelumnya untuk mencoba alur visual kelulusan.</li>
                    </ul>
                  </div>

                  <button
                    onClick={handleResetSearch}
                    className="w-full h-14 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-2 text-sm cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Kembali dan Coba Lagi
                  </button>
                </div>
              )}

            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="no-print w-full py-6 px-4 bg-white border-t border-slate-200 text-center mt-12">
        <div className="max-w-xl mx-auto space-y-2">
          <p className="text-xs font-bold text-slate-600">
            &copy; 2026 PPDB SMAN 1 Pinrang. All Rights Reserved.
          </p>
        </div>
      </footer>

    </div>
  );
}
