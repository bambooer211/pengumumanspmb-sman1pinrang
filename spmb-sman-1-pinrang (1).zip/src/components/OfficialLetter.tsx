import React, { useRef } from 'react';
import { Student } from '../types';
import { Printer, Download, ArrowLeft, CheckCircle, ShieldCheck } from 'lucide-react';

interface OfficialLetterProps {
  student: Student;
  onBack: () => void;
}

export default function OfficialLetter({ student, onBack }: OfficialLetterProps) {
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    const printContent = printRef.current?.innerHTML;
    const originalContent = document.body.innerHTML;

    if (printContent) {
      // Create a clean print frame state
      window.print();
    }
  };

  // Generate dynamic QR code URL
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=VERIFIED-SPMB-SMAN1PINRANG-NISN-${student.nisn}`;

  return (
    <div className="max-w-3xl mx-auto my-4 px-4 sm:px-6">
      {/* Action panel */}
      <div className="no-print bg-white rounded-2xl shadow-sm border border-slate-100 p-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors py-2 px-3 rounded-lg hover:bg-slate-50 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Hasil
        </button>
        <div className="flex gap-3 w-full sm:w-auto">
          <button
            onClick={() => window.print()}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 px-5 rounded-xl transition-all shadow-md shadow-emerald-600/10 hover:shadow-emerald-600/20 text-sm cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Cetak / Simpan PDF
          </button>
        </div>
      </div>

      <div className="no-print bg-amber-50 border border-amber-200 text-amber-800 rounded-xl p-4 mb-6 text-xs sm:text-sm flex gap-3">
        <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold mb-1">💡 Tips Cetak PDF di HP / Laptop:</p>
          <p className="opacity-90">
            Klik tombol <strong>Cetak / Simpan PDF</strong> di atas. Pada bagian printer, pilih opsi <strong>Simpan sebagai PDF (Save as PDF)</strong>. Untuk tampilan terbaik, aktifkan opsi <strong>Cetak background graphics</strong> di pengaturan browser Anda.
          </p>
        </div>
      </div>

      {/* Official Letter Container */}
      <div 
        ref={printRef}
        className="print-card bg-white rounded-2xl shadow-xl border border-slate-200 p-6 sm:p-12 text-slate-800 leading-relaxed relative overflow-hidden"
      >
        {/* Background Watermark */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.02]">
          <span className="text-[12rem] font-bold select-none rotate-12">SMAN1</span>
        </div>

        {/* Letter Head (Kop Surat) */}
        <div className="flex items-center border-b-[3px] border-slate-900 pb-4 mb-6 gap-4">
          {/* Circular School Crest Placeholder */}
          <div className="w-14 h-14 sm:w-20 sm:h-20 rounded-full border-2 border-slate-700 bg-slate-50 flex items-center justify-center shrink-0">
            <span className="text-xl sm:text-2xl font-bold tracking-tighter text-slate-800">SMAN1</span>
          </div>
          <div className="text-center flex-1">
            <h1 className="text-base sm:text-xl font-bold uppercase tracking-wide text-slate-950">
              Pemerintah Provinsi Sulawesi Selatan
            </h1>
            <h2 className="text-sm sm:text-lg font-bold uppercase text-slate-950">
              Dinas Pendidikan - UPT SMAN 1 Pinrang
            </h2>
            <p className="text-[10px] sm:text-xs text-slate-600 mt-1 italic">
              Alamat: Jl. Bintang No.2, Macorawalie, Kec. Watang Sawitto, Kabupaten Pinrang, Sulawesi Selatan 91212
            </p>
            <p className="text-[10px] sm:text-xs text-slate-500">
              Website: sman1pinrang.sch.id | Email: info@sman1pinrang.sch.id
            </p>
          </div>
        </div>

        {/* Letter Title */}
        <div className="text-center mb-6">
          <h3 className="font-bold underline text-sm sm:text-base tracking-wide text-slate-900 uppercase">
            SURAT KETERANGAN KELULUSAN SELEKSI
          </h3>
          <p className="text-xs text-slate-600 font-mono">
            Nomor: B/421.3/890/SMAN1/PPDB/2026
          </p>
        </div>

        {/* Introduction */}
        <p className="text-xs sm:text-sm text-slate-800 mb-4 text-justify">
          Berdasarkan hasil sidang pleno penetapan kelulusan Panitia Penerimaan Peserta Didik Baru (PPDB) UPT SMAN 1 Pinrang Tahun Pelajaran 2026/2027 atas evaluasi kriteria kelulusan jalur Zona 1, Afirmasi, dan Perpindahan Tugas Orang Tua (Mutasi), dengan ini Kepala Sekolah menerangkan bahwa:
        </p>

        {/* Student Biodata Table */}
        <div className="bg-slate-50 rounded-xl p-4 sm:p-6 mb-6 border border-slate-100">
          <table className="w-full text-xs sm:text-sm text-left border-collapse">
            <tbody>
              <tr className="border-b border-slate-200/50">
                <td className="py-2.5 font-semibold text-slate-500 w-1/3 sm:w-1/4">Nama Lengkap</td>
                <td className="py-2.5 font-bold text-slate-900">: {student.name}</td>
              </tr>
              <tr className="border-b border-slate-200/50">
                <td className="py-2.5 font-semibold text-slate-500">NISN</td>
                <td className="py-2.5 font-mono text-slate-900 font-bold">: {student.nisn}</td>
              </tr>
              <tr className="border-b border-slate-200/50">
                <td className="py-2.5 font-semibold text-slate-500">Jenis Kelamin</td>
                <td className="py-2.5 text-slate-800">: {student.gender}</td>
              </tr>
              <tr className="border-b border-slate-200/50">
                <td className="py-2.5 font-semibold text-slate-500">Asal Sekolah</td>
                <td className="py-2.5 text-slate-800">: {student.schoolOrigin}</td>
              </tr>
              <tr className="border-b border-slate-200/50">
                <td className="py-2.5 font-semibold text-slate-500">Jalur Pendaftaran</td>
                <td className="py-2.5 text-slate-800 font-medium">: {student.jalur}</td>
              </tr>
              <tr>
                <td className="py-2.5 font-semibold text-slate-500">Nilai / Skor Akhir</td>
                <td className="py-2.5 text-emerald-700 font-extrabold">: {student.score.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Status Statement */}
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-950 rounded-xl p-4 mb-6 text-center">
          <p className="text-xs uppercase font-semibold text-emerald-800 tracking-wider mb-1">
            Status Kelulusan
          </p>
          <p className="text-base sm:text-lg font-black tracking-wide text-emerald-700">
            Dinyatakan: LULUS SELEKSI
          </p>
        </div>

        {/* Steps/Advisory */}
        <div className="mb-8">
          <h4 className="font-bold text-xs sm:text-sm text-slate-900 mb-3">
            ⚠️ Langkah Wajib Berikutnya:
          </h4>
          <ol className="list-decimal pl-5 text-[11px] sm:text-xs text-slate-700 space-y-3 text-justify">
            <li>
              Melakukan pendaftaran ulang secara langsung (offline) di Sekretariat Panitia PPDB SMAN 1 Pinrang pada jadwal berikut:
              <div className="mt-1 bg-emerald-50 text-emerald-950 font-bold border border-emerald-100 px-3 py-1.5 rounded-lg inline-block font-mono">
                {student.registrationDate || '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'}
              </div>
            </li>
            <li>
              Mempersiapkan dan membawa berkas pendaftaran ulang yang dimasukkan ke dalam map:
              <ul className="list-disc pl-5 mt-1.5 space-y-1 font-semibold text-slate-800">
                <li>Bukti Pendaftaran dan Verifikasi</li>
                <li>Fotocopy Rapor 1 Rangkap</li>
                <li>Surat Keterangan Lulus Asli</li>
                <li>Fotocopy Ijazah SD (2 Lembar)</li>
                <li>Fotocopy Akta Kelahiran & KK (2 Lembar)</li>
                <li>Pas Foto 3 x 4 (3 Lembar)</li>
                <li>Pakta Integritas</li>
              </ul>
            </li>
            <li>
              Apabila calon peserta didik tidak melakukan daftar ulang hingga batas waktu yang telah ditentukan, yaitu tanggal <strong>15 Juni 2026 pukul 16:00 WITA</strong>, maka yang bersangkutan dianggap mengundurkan diri dan hak kelulusannya dinyatakan batal.
            </li>
          </ol>
        </div>

        {/* Footer info (Signatures & Verification Code) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-end pt-4 border-t border-slate-100">
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left gap-2">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">
              Digital Signature Verification
            </span>
            <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-lg border border-slate-150">
              <img 
                src={qrCodeUrl} 
                alt="Verification QR" 
                className="w-16 h-16 sm:w-20 sm:h-20 bg-white"
                referrerPolicy="no-referrer"
              />
              <div className="text-left">
                <p className="text-[9px] font-mono text-slate-500 leading-normal">
                  Dokumen ini sah dan diterbitkan secara elektronik oleh Panitia SPMB SMAN 1 Pinrang.
                </p>
                <div className="flex items-center gap-1 text-emerald-600 font-semibold text-[10px] mt-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  Terverifikasi Sistem
                </div>
              </div>
            </div>
          </div>

          <div className="text-center sm:text-right relative pb-2 sm:pr-4 flex flex-col items-center sm:items-end">
            <p className="text-xs text-slate-600 mb-1">
              Pinrang, {new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
            <p className="text-xs font-bold text-slate-800 mb-12">
              Kepala UPT SMAN 1 Pinrang,
            </p>

            {/* Simulated Stamp and Principal Signature */}
            <div className="relative w-48 h-16 flex items-center justify-center sm:justify-end">
              {/* Simulated Blue Signature Line */}
              <div className="absolute right-4 top-2 select-none pointer-events-none text-blue-600 font-display italic font-semibold text-lg opacity-85 rotate-[-5deg]">
                Guntur Malik
              </div>
              
              {/* Simulated Circular Red Stamp Overlay */}
              <div className="absolute right-12 top-[-10px] select-none pointer-events-none w-20 h-20 rounded-full border border-dashed border-red-500/40 bg-transparent flex items-center justify-center rotate-[15deg]">
                <div className="w-16 h-16 rounded-full border border-double border-red-500/40 flex flex-col items-center justify-center">
                  <span className="text-[6px] font-bold text-red-500/50 tracking-tighter">SMAN 1 PINRANG</span>
                  <span className="text-[4px] text-red-500/40">KEPALA SEKOLAH</span>
                </div>
              </div>
            </div>

            <p className="text-xs font-bold text-slate-900 underline">
              Drs. H. Guntur, M.Pd.
            </p>
            <p className="text-[10px] text-slate-500 font-mono mt-0.5">
              NIP. 19680312 199303 1 008
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
