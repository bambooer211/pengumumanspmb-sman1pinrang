import { Student } from '../types';

export const STUDENTS_DATA: Student[] = [
  // --- JALUR MUTASI (9 SISWA) ---
  {
    nisn: '0104916149',
    name: 'FATIMAH AKHMAD',
    gender: 'Perempuan',
    schoolOrigin: 'SMP ISLAM TERPADU AL IKHLAS',
    jalur: 'Mutasi',
    score: 9960.606,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0104031113',
    name: 'ZAHWA SALSABILA BUSTAN',
    gender: 'Perempuan',
    schoolOrigin: 'SMP ISLAM TERPADU AL IKHLAS',
    jalur: 'Mutasi',
    score: 9648.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0102922291',
    name: 'ASMAUL HUSNA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Mutasi',
    score: 8379.168,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0101700439',
    name: 'SURYA MULIANA AMUL',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 4 PINRANG',
    jalur: 'Mutasi',
    score: 8074.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0116418122',
    name: 'Khayla Zafirah',
    gender: 'Perempuan',
    schoolOrigin: 'PESANTREN PUTERI UMMUL MUKMININ AISYIYAH',
    jalur: 'Mutasi',
    score: 6444.034,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0115335904',
    name: 'ANDI NAJLA JANEETA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 2 MATTIRO BULU',
    jalur: 'Mutasi',
    score: 4486.59,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114457715',
    name: 'IKA RISMALA DEWIANTI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PATAMPANUA',
    jalur: 'Mutasi',
    score: 148.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0111590095',
    name: 'Muhammad Sulhidar Ibrahim',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PATAMPANUA',
    jalur: 'Mutasi',
    score: 128.63,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0107673219',
    name: 'AHMADI AKBAR ISMAIL',
    gender: 'Laki-laki',
    schoolOrigin: 'SMP NEGERI 1 BUA PONRANG',
    jalur: 'Mutasi',
    score: 28.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },

  // --- JALUR DOMISILI ZONA 1 (65 SISWA) ---
  {
    nisn: '0117307668',
    name: 'GINA FAKHIRAH PUTRI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9966.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0106387783',
    name: 'MUH. KHOIRUL AZZAM',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 2 PINRANG',
    jalur: 'Zona 1',
    score: 9943.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0117427795',
    name: 'A. MUH. WIRA ARRAHMAN',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9938.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103536556',
    name: 'SHIRIL FIRMAN',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 8 PINRANG',
    jalur: 'Zona 1',
    score: 9935.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114547418',
    name: 'NUR FAKHRIYAH ALI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9934.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0107228099',
    name: 'NABILA NUR AZIZAH',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9929.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0115661960',
    name: 'MUZAYYANAH NURFAIQAH SYAH',
    gender: 'Perempuan',
    schoolOrigin: 'PKBM MARKAZ WAHDAH ISLAMIYAH',
    jalur: 'Zona 1',
    score: 9926.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114346004',
    name: 'MUH. DZAKY YUNUS',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9922.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0108842603',
    name: 'ANDI MUHAMMAD FAISHAL',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9919.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0119171416',
    name: 'MUHAMMAD FAIDHI FAIQ',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9910.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0102275492',
    name: 'NABIIL AHMAD ALKAUTSAR',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9906.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0107244896',
    name: 'MUH. ADITYA RAMADAN. N',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9890.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0118620128',
    name: 'FANY RAHMA SARI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9889.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114110747',
    name: 'ST. SIDRAH',
    gender: 'Perempuan',
    schoolOrigin: 'MTSN PINRANG',
    jalur: 'Zona 1',
    score: 9867.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0116037157',
    name: 'Muh. Nabil Asyam',
    gender: 'Laki-laki',
    schoolOrigin: 'MTSS ITTIHADIYAH TANREASSONA',
    jalur: 'Zona 1',
    score: 9865.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0112502407',
    name: 'Raisah Zahrah Wahyudi',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9863.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0111513700',
    name: 'SYIFANI RAHMAHAYU SYAM',
    gender: 'Perempuan',
    schoolOrigin: 'SMP ISLAM TERPADU AL IKHLAS',
    jalur: 'Zona 1',
    score: 9828.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0119375104',
    name: 'MUH. FAIZ MUSYAWIR',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9825.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109194735',
    name: 'ANDI NUR LATHIIFA',
    gender: 'Perempuan',
    schoolOrigin: 'SMP ISLAM TERPADU AL IKHLAS',
    jalur: 'Zona 1',
    score: 9814.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0116250326',
    name: 'AHMAD FAUZAN',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9812.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0111120282',
    name: 'Dzakirah Talita Khayyirah Nazar',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9793.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109951051',
    name: 'SITTI FATIMAH ZAHRA NASIR',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Zona 1',
    score: 9792.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114092866',
    name: 'MUH. AZHAR FALAH K.',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9789.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0101631363',
    name: 'Muhammad Ibnu Khuzaimah',
    gender: 'Laki-laki',
    schoolOrigin: 'MTSS ITTIHADIYAH TANREASSONA',
    jalur: 'Zona 1',
    score: 9785.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0119590816',
    name: 'SAFANA MARWA ANHA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9773.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0105277361',
    name: 'A. Irsyad Hafiz Zulkarnain',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9771.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0105353335',
    name: 'Beiby Rahman',
    gender: 'Perempuan',
    schoolOrigin: 'MTSN PINRANG',
    jalur: 'Zona 1',
    score: 9765.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '3110721822',
    name: 'SERTIKA NURTASYA',
    gender: 'Perempuan',
    schoolOrigin: 'SMP AL QADRI ISLAMIC SCHOL',
    jalur: 'Zona 1',
    score: 9765.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114091815',
    name: 'ANDI MUH. FAQHI',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9765.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0102481299',
    name: 'SEPTIASYAH RAMADHANI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9764.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0106270254',
    name: 'AMIRA ANDIKA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9750.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0117363084',
    name: 'DZAKIYAH RAFIFAH ZAHRA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9748.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109209743',
    name: 'SYADZA UFAIRAH',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9744.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0108084405',
    name: 'ALFYANI REZKY. P',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9739.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0105554164',
    name: 'CRISTOFER PRASETIA',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9728.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0107875680',
    name: 'AINAYYA AIRUS IZZA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9728.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0101665277',
    name: 'IBNU KHAYYUM AL - JUFRI',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9727.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0106697746',
    name: 'MUH. FAKHRI RAHMAN',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9725.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103944817',
    name: 'FIRDAUS KHAIRUL HISYAM',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9722.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103933735',
    name: 'FATIA ADILA ZAHRA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9721.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0105636203',
    name: 'AKRAMULLAH SAM',
    gender: 'Laki-laki',
    schoolOrigin: 'MTSS IUJ DDI LERANG-LERANG',
    jalur: 'Zona 1',
    score: 9721.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0102435440',
    name: 'CHAERUNNIZA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9716.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0112849950',
    name: 'MUHAMMAD FATHIR',
    gender: 'Laki-laki',
    schoolOrigin: 'MTs TASSBEH BAITUL QUR`AN',
    jalur: 'Zona 1',
    score: 9711.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109690502',
    name: 'MUH. NUR ASYAM',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9710.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0111751885',
    name: 'SHIFA AZ-ZAHRA. S',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9710.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0117914383',
    name: 'A. MOCH. ALGIFAHRI AQSA CITRA',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9709.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0111980181',
    name: 'MAGHFIRA ASYIKIN',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9709.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0119827163',
    name: 'NAJWA AQEELA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9707.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114811032',
    name: 'MUHAMMAD ALIF PUTRA TASLIM',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9701.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114024906',
    name: 'Ahmad Raihan Amal',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9694.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0112273813',
    name: 'MAHARANI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9671.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0104124026',
    name: 'ANDI FABYAN PRATAMA',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9668.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0116453467',
    name: 'FARSYAH LA TENRI AJI',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9655.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103461980',
    name: 'MUH. DAFFA PRATAMA',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9649.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0104012041',
    name: 'MUH. ALIF AKBAR RAFSANJANI',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9648.17,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0119547570',
    name: 'RESKY FADILLA FAKHRAINI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9627.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0117605594',
    name: 'SYAFIRAH ADINDA SALEH',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9627.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0111531954',
    name: 'AKHIFA ZHAFIRA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9625.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0108234939',
    name: 'A. Muhammad Fathir',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9609.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109975373',
    name: 'AYUDYA SYAQILAH PUTRI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9600.33,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0117557892',
    name: 'NISFATHUL KHAERA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9595.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109934358',
    name: 'Anisa Putri Ardiansyah',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9593.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109035803',
    name: 'FAIZAL BASRI',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9588.67,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103424199',
    name: 'Aqiilah Nahdah Fitriyani',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9580.50,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103278199',
    name: 'A. MUH. ALI ADITYA SYAHBULLAH',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Zona 1',
    score: 9573.83,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },

  // --- JALUR AFIRMASI (36 SISWA) ---
  {
    nisn: '0101148864',
    name: 'FAIZ AIMAN',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 8339.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0117335641',
    name: 'TASYA AULIA ANUGRAH ILAHI. T',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 2 PINRANG',
    jalur: 'Afirmasi',
    score: 7709.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0095441840',
    name: 'SALMIAH ZALSABILLAH',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9520.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0102665464',
    name: 'NUR AMELIA PUTRI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9129.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103380456',
    name: 'NUR REZKY FITRIANI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 5420.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0108892468',
    name: 'MUHAMMAD ARYA RAHMADIANSYAH',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 9576.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109693964',
    name: 'YULIANTI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 8 PINRANG',
    jalur: 'Afirmasi',
    score: 7342.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103627705',
    name: 'Siti Nursyuhada',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 8683.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0103004497',
    name: 'NUR ALIFIA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9449.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0112069327',
    name: 'SALSABILA HUMAERA',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 8 PINRANG',
    jalur: 'Afirmasi',
    score: 7301.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114817444',
    name: 'MARSELINA KANLI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 9212.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0101750465',
    name: 'Muhammad Akbar',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9061.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0105420266',
    name: 'Sahra Asyifa',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9286.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114840065',
    name: 'ZAHWAH SALSABILAH. MUH. YUSUF. P',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9552.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0106391281',
    name: 'ASRI HAMZA',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 9753.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0105199003',
    name: 'Rahmi Yani',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 8 PINRANG',
    jalur: 'Afirmasi',
    score: 7682.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109283227',
    name: 'Muhammad Riski Saputra',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 8289.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0102332669',
    name: 'AAN NAIL ATTAR RAMADHAN',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 7010.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0113177458',
    name: 'Duta Tenri Waru',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9063.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0102841950',
    name: 'AQIL AZMI NURFAYYADH',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9470.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0104380398',
    name: 'M. Fais',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 9057.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0105641469',
    name: 'MUH. YAHYA ABSTRI',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 2 PINRANG',
    jalur: 'Afirmasi',
    score: 7148.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0118034343',
    name: 'SULKIFLI SYUKUR',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 4 PINRANG',
    jalur: 'Afirmasi',
    score: 5430.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0112862074',
    name: 'NURLINDA MUHAMMAD',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 8162.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0118525813',
    name: 'MUH. RIZKY SYAPUTRA',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 8298.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0104199342',
    name: 'MUHAMMAD SIKRA',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 2 PINRANG',
    jalur: 'Afirmasi',
    score: 8230.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0101830090',
    name: 'HUSNUL HATIMAH',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 8836.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0109906665',
    name: 'A. TEGAR SETIAWAN',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 9320.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0111585442',
    name: 'MIFTA FARIS',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 9038.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0114932503',
    name: 'ADWIL',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 2 PINRANG',
    jalur: 'Afirmasi',
    score: 7975.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0107120026',
    name: 'M. SOFIYAN HIDAYAT',
    gender: 'Laki-laki',
    schoolOrigin: 'UPT SMP NEGERI 2 MATTIRO BULU',
    jalur: 'Afirmasi',
    score: 4351.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0104813251',
    name: 'NUR AINUN QALBI',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 2 PINRANG',
    jalur: 'Afirmasi',
    score: 4749.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0108921461',
    name: 'HAYATUN NUFUS SALEH',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 5 PINRANG',
    jalur: 'Afirmasi',
    score: 8611.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '0101804615',
    name: 'ALMIRA NAHDA SAFIKHA',
    gender: 'Perempuan',
    schoolOrigin: 'MTSS MUHAMMADIYAH PINRANG',
    jalur: 'Afirmasi',
    score: 9224.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '3106436048',
    name: 'RAWATI',
    gender: 'Perempuan',
    schoolOrigin: 'SMP MUHAMMADIYAH PINRANG',
    jalur: 'Afirmasi',
    score: 7449.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  },
  {
    nisn: '3114110299',
    name: 'HAERUNNISA. H',
    gender: 'Perempuan',
    schoolOrigin: 'UPT SMP NEGERI 1 PINRANG',
    jalur: 'Afirmasi',
    score: 7943.00,
    isPassed: true,
    registrationDate: '12 Jun 2026 07:30 - 15 Jun 2026 16:00 WITA'
  }
];
