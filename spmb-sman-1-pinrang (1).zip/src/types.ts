export interface Student {
  nisn: string;
  name: string;
  gender: 'Laki-laki' | 'Perempuan';
  schoolOrigin: string;
   jalur: 'Zona 1' | 'Afirmasi' | 'Mutasi';
  score: number;
  isPassed: boolean;
  registrationDate?: string;
}
